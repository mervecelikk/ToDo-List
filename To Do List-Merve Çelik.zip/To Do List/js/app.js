
const form= document.querySelector('#todolist-login')
const form= document.querySelector('#todolist-form')









  //add database
form.addEventListener('submit', (e)=>{

e.preventDefault();

db.collection('Todolist').add({

    name:form.name.value,
    surname:form.surname.value,
    email:form.email.value,
    password:form.password.value

});

})